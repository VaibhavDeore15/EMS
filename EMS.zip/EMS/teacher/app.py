from flask import Flask,request,redirect,render_template,url_for,flash,session,Blueprint
import sqlite3, os
from datetime import datetime
from fpdf import FPDF
from flask import send_file
import io
prof_DB = 'teacher.db'
USER_DB="C:\\Users\\265600\\Desktop\\EMS\\std\\users.db"
query_db="C:\\Users\\265600\\Desktop\\EMS\\std\\queries.db"

app=Flask(__name__)
app.secret_key = 'your_secret_key' 

teacher_bp = Blueprint('teacher_bp', __name__, template_folder='templates')

@teacher_bp.route('/')
def student_home():
    return render_template('login.html')

def get_user_db_connection():
    conn = sqlite3.connect(prof_DB)
    conn.row_factory = sqlite3.Row
    return conn

def query_db_connection():
    conn = sqlite3.connect(query_db)
    conn.row_factory = sqlite3.Row
    return conn

def user_connection():
    conn = sqlite3.connect(USER_DB)
    conn.row_factory = sqlite3.Row
    return conn

# ---------------------------
# Database initialization functions
# ---------------------------
def init_user_db():
    conn = get_user_db_connection()
    cur = conn.cursor()
    cur.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            branch TEXT NOT NULL,
            email TEXT
        )
    ''')

    conn.commit()
    conn.close()

init_user_db()

def init_exam_table():
    conn = get_user_db_connection()
    cur = conn.cursor()
    cur.execute('''
        CREATE TABLE IF NOT EXISTS exams (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            date TEXT NOT NULL,
            duration INTEGER,
            branch TEXT,
            created_by TEXT,
            status TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

# Call it at the bottom of your app.py
init_exam_table()
def init_student_tables():
    conn = get_user_db_connection()
    cur = conn.cursor()
    
    cur.execute('''
        CREATE TABLE IF NOT EXISTS student_answers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            exam_id INTEGER,
            question_id INTEGER,
            selected_option TEXT
        )
    ''')
    
    cur.execute('''
        CREATE TABLE IF NOT EXISTS results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            exam_id INTEGER,
            score INTEGER,
            total INTEGER
        )

    ''')
    

    conn.commit()
    conn.close()

init_student_tables()


# Registration route
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password']
        branch = request.form['branch']
        email = request.form['email']
        if not username or not password:
            flash("Please fill out all fields", "danger")
            return redirect(url_for('register'))
        conn = get_user_db_connection()
        cur = conn.cursor()
        try:
            cur.execute("INSERT INTO users (username, password, branch, email) VALUES (?, ?, ?, ?)", 
            (username, password, branch, email))
            conn.commit()
            flash("Registration successful, please login", "success")
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash("Username already exists", "danger")
            return redirect(url_for('register'))
        finally:
            conn.close()
    return render_template('register.html')

# Login route
# Fixed login render
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password']
        conn = get_user_db_connection()
        user = conn.execute("SELECT * FROM users WHERE username = ? AND password = ?", (username, password)).fetchone()
        conn.close()
        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['branch'] = user['branch']
            flash("Logged in successfully", "success")
            return redirect(url_for('dashboard'))

        else:
            flash("Invalid credentials", "danger")
            return redirect(url_for('login'))
    return render_template('login.html')  

@app.route('/dashboard')
def dashboard():
    if 'username' not in session:
        return redirect(url_for('login'))

    conn = get_user_db_connection()
    cur = conn.cursor()
    # Count total exams created by this teacher
    cur.execute("SELECT COUNT(*) FROM exams WHERE created_by = ?", (session['username'],))
    total_exams = cur.fetchone()[0]
    conn.close()

    # Count students who appeared in any exam (from users.db)
    student_conn = user_connection()
    student_cur = student_conn.cursor()
    student_cur.execute("SELECT COUNT(DISTINCT user_id) FROM results")
    students_appeared = student_cur.fetchone()[0]
    student_conn.close()

    return render_template("dashboard.html",total_exams=total_exams,students_appeared=students_appeared)

@app.route('/view_queries')
def view_queries():
    conn = query_db_connection()
    cur = conn.cursor()

    cur.execute("SELECT * FROM querie ORDER BY submitted_at DESC")
    queries = cur.fetchall()
    conn.close()

    return render_template('view_queries.html', queries=queries)


@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out.')
    return redirect(url_for('login'))

@app.route('/create_exam', methods=['GET', 'POST'])
def create_exam():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        title = request.form['title']
        date = request.form['date']
        duration = request.form['duration']
        branch = session['branch']
        created_by = session['username']

        conn = get_user_db_connection()
        cur = conn.cursor()
        cur.execute('INSERT INTO exams (title, date, duration, branch, created_by,status) VALUES (?, ?, ?, ?, ?,?)',
                    (title, date, duration, branch, created_by, 'active'))
        conn.commit()
        conn.close()

        flash("Exam created successfully", "success")
        return redirect(url_for('dashboard'))
    
    return render_template('create_exam.html')

def init_question_table():
    conn = get_user_db_connection()
    cur = conn.cursor()
    cur.execute('''
        CREATE TABLE IF NOT EXISTS questions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            exam_id INTEGER,
            question_text TEXT,
            option_a TEXT,
            option_b TEXT,
            option_c TEXT,
            option_d TEXT,
            correct_option TEXT,
            FOREIGN KEY (exam_id) REFERENCES exams (id)
        )
    ''')
    try:
        cur.execute('ALTER TABLE exams ADD COLUMN status TEXT DEFAULT "active"')
    except sqlite3.OperationalError:
        pass  # Ignore if column already exists
    conn.commit()
    conn.close()


init_question_table()

@app.route('/exam/<int:exam_id>/add-question', methods=['GET', 'POST'])
def add_question(exam_id):
    if request.method == 'POST':
        q_text = request.form['question_text']
        a = request.form['option_a']
        b = request.form['option_b']
        c = request.form['option_c']
        d = request.form['option_d']
        correct = request.form['correct_option']

        conn = get_user_db_connection()
        cur = conn.cursor()
        cur.execute('''INSERT INTO questions 
            (exam_id, question_text, option_a, option_b, option_c, option_d, correct_option)
            VALUES (?, ?, ?, ?, ?, ?, ?)''', 
            (exam_id, q_text, a, b, c, d, correct))
        conn.commit()
        conn.close()

        flash("Question added", "success")
        return redirect(url_for('manage_exams', exam_id=exam_id))

    return render_template('add_question.html', exam_id=exam_id)

@app.route('/exam/<int:exam_id>/set-status/<status>')
def set_exam_status(exam_id, status):
    if status not in ['active', 'ended']:
        flash("Invalid status", "danger")
        return redirect(url_for('manage_exams'))

    conn = get_user_db_connection()
    cur = conn.cursor()
    cur.execute("UPDATE exams SET status = ? WHERE id = ?", (status, exam_id))
    conn.commit()
    conn.close()

    flash(f"Exam status set to {status}", "info")
    return redirect(url_for('manage_exams'))

@app.route('/manage-exams')
def manage_exams():
    conn = get_user_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM exams WHERE created_by = ?", (session['username'],))
    exams = cur.fetchall()
    conn.close()
    return render_template('manage_exams.html', exams=exams)



def generate_all_results_pdf():
    conn = user_connection()
    cur = conn.cursor()

    # Fetch all results with student usernames
    cur.execute("""
        SELECT u.username, r.exam_name, r.date, r.score, r.total
        FROM results r
        JOIN users u ON u.id = r.user_id
    """)
    data = cur.fetchall()
    conn.close()

    pdf = FPDF()
    pdf.add_page()

    # Title
    pdf.set_font("Arial", "B", 16)
    pdf.cell(0, 10, "All Students Exam Results", 0, 1, "C")
    pdf.ln(5)

    # Headers
    pdf.set_font("Arial", "B", 12)
    pdf.cell(40, 10, "Student", 1)
    pdf.cell(50, 10, "Exam", 1)
    pdf.cell(30, 10, "Date", 1)
    pdf.cell(20, 10, "Score", 1)
    pdf.cell(20, 10, "Total", 1)
    pdf.cell(30, 10, "Status", 1)
    pdf.ln()

    # Rows
    pdf.set_font("Arial", "", 10)
    for row in data:
        status = "Passed" if row["score"] >= 0.4 * row["total"] else "Failed"
        pdf.cell(40, 10, str(row["username"])[:15], 1)
        pdf.cell(50, 10, str(row["exam_name"])[:24], 1)
        pdf.cell(30, 10, str(row["date"]), 1)
        pdf.cell(20, 10, str(row["score"]), 1)
        pdf.cell(20, 10, str(row["total"]), 1)
        pdf.cell(30, 10, status, 1)
        pdf.ln()

    # Save to buffer
    pdf_output = pdf.output(dest='S').encode('latin1')
    buffer = io.BytesIO(pdf_output)
    buffer.seek(0)
    return buffer

@app.route('/download_all_results')
def download_all_results():
    if 'username' not in session:
        flash("Please login first", "danger")
        return redirect(url_for('login'))

    pdf_buffer = generate_all_results_pdf()
    return send_file(pdf_buffer, as_attachment=True, download_name="all_results.pdf", mimetype="application/pdf")








if __name__== "__main__":
    app.run(debug=True)