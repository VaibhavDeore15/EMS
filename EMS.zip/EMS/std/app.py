from flask import Flask,request,redirect,render_template,url_for,flash,session
from flask import Blueprint
import sqlite3, os
from datetime import datetime
from flask import jsonify

USER_DB = 'users.db'
USER_QUE='queries.db'
EXAM_DB = 'C:\\Users\\265600\\Desktop\\EMS\\teacher\\teacher.db'
PROCTOR_DB="C:\\Users\\265600\\Desktop\\EMS\\protector\\proctor_logs.db"


app=Flask(__name__)
app.secret_key = 'your_secret_key' 

std_bp = Blueprint('std_bp', __name__, template_folder='templates')

@std_bp.route('/')
def student_home():
    return render_template('home.html')

def get_user_db_connection():
    conn = sqlite3.connect(USER_DB)
    conn.row_factory = sqlite3.Row
    return conn

def get_exam_db_connection():
    conn = sqlite3.connect(EXAM_DB)
    conn.row_factory = sqlite3.Row
    return conn


def get_queries_db_connection():
    conn = sqlite3.connect(USER_QUE)
    conn.row_factory = sqlite3.Row
    return conn

def init_queries_db():
    conn = get_queries_db_connection()
    cur = conn.cursor()
    
    cur.execute('''
    CREATE TABLE IF NOT EXISTS querie (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        username TEXT NOT NULL,
        message TEXT NOT NULL,
        submitted_at TEXT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')
    conn.commit()
    conn.close()
# ---------------------------
# Database initialization functions
# ---------------------------
def init_user_db():
    conn = get_user_db_connection()
    cur = conn.cursor()
    # Create results table with user_id column
    cur.execute('''
        CREATE TABLE IF NOT EXISTS results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            exam_name TEXT NOT NULL,
            date TEXT NOT NULL,
            score INTEGER,
            total INTEGER,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')

    # Keep users table
    cur.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            branch TEXT NOT NULL
        )
    ''')

    conn.commit()
    conn.close()



init_user_db()
init_queries_db()

# Registration route
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password']
        branch = request.form['branch']
        if not username or not password:
            flash("Please fill out all fields", "danger")
            return redirect(url_for('register'))
        conn = get_user_db_connection()
        cur = conn.cursor()
        try:
            cur.execute("INSERT INTO users (username, password, branch) VALUES (?, ?, ?)", (username, password,branch))
            conn.commit()
            flash("Registration successful, please login", "success")
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash("Username already exists", "danger")
            return redirect(url_for('register'))
        finally:
            conn.close()
    return render_template('register.html')

# Login route
# Fixed login render
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password']
        conn = get_user_db_connection()
        user = conn.execute("SELECT * FROM users WHERE username = ? AND password = ?", (username, password)).fetchone()
        conn.close()
        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['branch'] = user['branch']
            flash("Logged in successfully", "success")
            return redirect(url_for('home'))
        else:
            flash("Invalid credentials", "danger")
            return redirect(url_for('login'))
    return render_template('login.html')  

# New route to student dashboard
@app.route('/home')
def home():
    if 'user_id' not in session:
        flash("Please login first", "warning")
        return redirect(url_for('login'))
    return render_template('home.html', username=session['username'])


@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out.')
    return redirect(url_for('login'))

@app.route('/result')
def result():
    if 'user_id' not in session:
        flash("Please login first", "warning")
        return redirect(url_for('login'))
    
    conn = get_user_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT exam_name, date, score, total FROM results WHERE user_id = ?', (session['user_id'],))
    user_results = cur.fetchall()
    conn.close()

    # Calculate pass/fail and send to template
    results_with_status = []
    for row in user_results:
        status = "✅ Passed" if row['score'] >= row['total'] * 0.4 else "❌ Failed"
        results_with_status.append({
            'exam': row['exam_name'],
            'date': row['date'],
            'score': f"{row['score']} / {row['total']}",
            'status': status
        })

    return render_template('result.html', results=results_with_status)


@app.route('/query', methods=['GET', 'POST'])
def query():
    if 'user_id' not in session:
        flash("Please login first", "warning")
        return redirect(url_for('login'))

    if request.method == 'POST':
        message = request.form['message'].strip()
        if not message:
            flash("Query cannot be empty", "danger")
            return redirect(url_for('query'))

        conn = get_queries_db_connection()
        cur = conn.cursor()
        cur.execute('''
            INSERT INTO querie (user_id, username, message, submitted_at)
            VALUES (?, ?,? , ?)
        ''', (session['user_id'],session['username'], message, datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
        conn.commit()
        conn.close()

        flash("Query submitted successfully!", "success")
        return redirect(url_for('home'))

    return render_template('query.html')


@app.route('/exams')
def exams():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = get_exam_db_connection()  # ✅ Use teacher DB here
    exams = conn.execute("SELECT * FROM exams WHERE status = 'active'").fetchall()
    conn.close()

    return render_template('exams.html', exams=exams)



@app.route('/exam/<int:exam_id>', methods=['GET', 'POST'])
def start_exam(exam_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = get_exam_db_connection()
    cur = conn.cursor()
    questions = cur.execute("SELECT * FROM questions WHERE exam_id = ?", (exam_id,)).fetchall()

    exam = cur.execute("SELECT title, duration FROM exams WHERE id = ?", (exam_id,)).fetchone()
    exam_title = exam['title'] if exam else f"Exam {exam_id}"
    duration = exam['duration']

    conn.close()

    return render_template('exam_page.html', questions=questions, exam_id=exam_id, exam_title=exam_title,duration=duration)


@app.route('/submit_exam/<int:exam_id>', methods=['POST'])
def submit_exam(exam_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    # ✅ Get questions from teacher DB
    conn = get_exam_db_connection()
    cur = conn.cursor()
    questions = cur.execute("SELECT * FROM questions WHERE exam_id = ?", (exam_id,)).fetchall()
    conn.close()

    score = 0
    for q in questions:
        selected = request.form.get(f"q{q['id']}")
        if selected and selected ==q['correct_option']:
            score += 1

    total = len(questions)

    # ✅ Save result in student DB (users.db) which has exam_name column
    user_conn = get_user_db_connection()
    user_cur = user_conn.cursor()

    exam_db = get_exam_db_connection()
    exam_cur = exam_db.cursor()
    exam_title_row = exam_cur.execute("SELECT title FROM exams WHERE id = ?", (exam_id,)).fetchone()
    exam_db.close()

    exam_title = exam_title_row['title'] if exam_title_row else f"Exam {exam_id}"

    user_cur.execute(
        "INSERT INTO results (user_id, exam_name, date, score, total) VALUES (?, ?, DATE('now'), ?, ?)",
        (session['user_id'], exam_title, score, total)
    )
    user_conn.commit()
    user_conn.close()

    flash(f"Exam submitted. You scored {score} out of {total}", "success")
    return redirect(url_for('result'))





if __name__== "__main__":
    app.run(debug=True)
    
