from flask import Flask
from std.app import std_bp
from teacher.app import teacher_bp
from protector.app import protector_bp

app = Flask(__name__, template_folder='templates', static_folder='static')
app.secret_key = 'super_secret'

# Register blueprints
app.register_blueprint(std_bp, url_prefix='/student')
app.register_blueprint(teacher_bp, url_prefix='/teacher')
app.register_blueprint(protector_bp, url_prefix='/protector')

if __name__ == "__main__":
    app.run(debug=True)
