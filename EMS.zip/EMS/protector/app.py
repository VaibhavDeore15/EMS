from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, make_response, render_template_string,Blueprint
from flask_cors import CORS
import sqlite3, os, base64, cv2
import numpy as np
from datetime import datetime
from xhtml2pdf import pisa
from io import BytesIO

app = Flask(__name__)
CORS(app)
app.secret_key = 'admin_secret'

PROCTOR_DB = 'proctor_logs.db'


protector_bp = Blueprint('protector_bp', __name__, template_folder='templates')

@protector_bp.route('/')
def student_home():
    return render_template('admin.html')
# Initialize DB
def init_proctor_db():
    conn = sqlite3.connect(PROCTOR_DB)
    cur = conn.cursor()
    cur.execute('''
        CREATE TABLE IF NOT EXISTS logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            username TEXT,
            exam_title TEXT,
            issue TEXT,
            timestamp TEXT
        )
    ''')
    conn.commit()
    conn.close()

init_proctor_db()

@app.route('/')
def home():
    return redirect(url_for('login'))

@app.route('/dashboard')
def dashboard():
    if 'admin' not in session:
        return redirect(url_for('login'))

    conn = sqlite3.connect(PROCTOR_DB)
    conn.row_factory = sqlite3.Row
    logs = conn.execute("SELECT * FROM logs ORDER BY exam_title, timestamp DESC").fetchall()
    conn.close()

    grouped = {}
    for log in logs:
        exam = log['exam_title']
        grouped.setdefault(exam, []).append(log)

    return render_template('dashboard.html', grouped_logs=grouped)

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        if request.form['username'] == 'admin' and request.form['password'] == 'admin123':
            session['admin'] = True
            return redirect(url_for('dashboard'))
        flash("Invalid credentials.")
    return render_template('admin.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/log-issue', methods=['POST'])
def log_issue():
    data = request.get_json()
    print("Log received:", data)

    conn = sqlite3.connect(PROCTOR_DB)
    cur = conn.cursor()
    cur.execute('''
        INSERT INTO logs (student_id, username, exam_title, issue, timestamp)
        VALUES (?, ?, ?, ?, ?)
    ''', (
        data.get('student_id'),
        data.get('username'),
        data.get('exam_title'),
        data.get('issue'),
        data.get('time')
    ))
    conn.commit()
    conn.close()

    return jsonify({"status": "success"}), 200

@app.route('/delete-log/<int:log_id>', methods=['POST'])
def delete_log(log_id):
    conn = sqlite3.connect(PROCTOR_DB)
    conn.execute("DELETE FROM logs WHERE id = ?", (log_id,))
    conn.commit()
    conn.close()
    flash("Log deleted", "success")
    return redirect(url_for('dashboard'))

@app.route('/download-logs/<exam_title>')
def download_exam_logs(exam_title):
    if 'admin' not in session:
        return redirect(url_for('login'))

    conn = sqlite3.connect(PROCTOR_DB)
    conn.row_factory = sqlite3.Row
    logs = conn.execute("SELECT * FROM logs WHERE exam_title = ? ORDER BY timestamp DESC", (exam_title,)).fetchall()
    conn.close()

    rendered = render_template_string("""
    <html>
    <head>
    <style>
        h2, h3 { color: #000; }
        ul { padding-left: 20px; }
        li { margin-bottom: 4px; }
    </style>
    </head>
    <body>
    <h2>Proctor Logs for {{ exam_title }}</h2>
    <ul>
    {% for log in logs %}
      <li>{{ log.timestamp }} — {{ log.username }} — {{ log.issue }}</li>
    {% endfor %}
    </ul>
    </body>
    </html>
    """, logs=logs, exam_title=exam_title)

    pdf = BytesIO()
    pisa.CreatePDF(rendered, dest=pdf)
    pdf.seek(0)

    response = make_response(pdf.read())
    response.headers['Content-Type'] = 'application/pdf'
    response.headers['Content-Disposition'] = f'attachment; filename={exam_title}_logs.pdf'
    return response

@app.route('/analyze-frame', methods=['POST'])
def analyze_frame():
    data = request.get_json()
    img_data = data['image'].split(',')[1]
    img_bytes = base64.b64decode(img_data)
    np_arr = np.frombuffer(img_bytes, np.uint8)
    frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.1, 4)

    issue = None
    if len(faces) == 0:
        issue = "No face detected"
    elif len(faces) > 1:
        issue = "Multiple faces detected"

    if issue:
        conn = sqlite3.connect(PROCTOR_DB)
        cur = conn.cursor()
        cur.execute('''
            INSERT INTO logs (student_id, username, exam_title, issue, timestamp)
            VALUES (?, ?, ?, ?, ?)
        ''', (
            data.get('student_id'),
            data.get('username'),
            data.get('exam_title'),
            issue,
            datetime.now().strftime("%d-%m-%Y %H:%M")
        ))
        conn.commit()
        conn.close()

    return jsonify({"status": "analyzed", "faces": len(faces)})

if __name__ == "__main__":
    app.run(debug=True, port=5001)
